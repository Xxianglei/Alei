package com.kang.learning.springboot.common.consts;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * 使用@ConfigurationProperties读取配置文件中自定义参数
 * 'prefix'指定参数前缀名
 * @author yingKang
 */
@Component
@ConfigurationProperties(prefix = "my-param", ignoreUnknownFields = true)
public class MyParamConst {

    private String hello;

    private String world;

    public String getHello() { return hello; }

    public void setHello(String hello) {this.hello = hello; }

    public String getWorld() { return world; }

    public void setWorld(String world) { this.world = world; }
}
