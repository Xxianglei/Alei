package com.kang.learning.springboot.controller;

import com.kang.learning.springboot.common.consts.MyParamConst;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author yingKang
 * @Company Java编程之道
 */
@RestController
@RequestMapping("/first")
public class FirstController {

    @Value(value = "${my-param.hello}")
    private String hello;

    @Value(value = "${my-param.world}")
    private String world;

    @Autowired
    private MyParamConst myParamConst;

    @GetMapping("/hello")
    public String helloWorld() {
        return "Hello World!";
    }

    @GetMapping("/hello2")
    public String helloWorld2() {
        return "@Value: " + hello + " " + world;
    }

    @GetMapping("/hello3")
    public String helloWorld3() {
        return  "@ConfigurationProperties： " + myParamConst.getHello() + " " + myParamConst.getWorld();
    }
}
