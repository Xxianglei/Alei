package com.kang.learning.springboot.controller;

import com.kang.learning.springboot.common.consts.MyParamConst;
import com.kang.learning.springboot.model.dto.MyResponse;
import com.kang.learning.springboot.model.dto.StudentDTO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

/**
 * @author yingKang
 * @Company Java编程之道
 */
@Api(tags = "第一个Collector")
@RestController
@RequestMapping("/first")
public class FirstController {

    @Value(value = "${my-param.hello}")
    private String hello;

    @Value(value = "${my-param.world}")
    private String world;

    @Autowired
    private MyParamConst myParamConst;

    @ApiOperation(value = "直接打印Hello World")
    @GetMapping("/hello")
    public String helloWorld() {
        return "Hello World!";
    }

    @ApiOperation(value = "@Value读取打印Hello World")
    @GetMapping("/hello2")
    public String helloWorld2() {
        return "@Value: " + hello + " " + world;
    }

    @ApiOperation(value = "@ConfigurationProperties读取打印Hello World")
    @GetMapping("/hello3")
    public String helloWorld3() {
        return  "@ConfigurationProperties： " + myParamConst.getHello() + " " + myParamConst.getWorld();
    }

    @ApiOperation(value = "新建学生信息")
    @PostMapping("/student")
    public MyResponse<StudentDTO> createStudent(@ApiParam("学生信息") @RequestBody StudentDTO studentDTO) {
        return MyResponse.ok(studentDTO);
    }

    @ApiOperation(value = "查询学生信息")
    @GetMapping("/student/{id}")
    public MyResponse<StudentDTO> getStudent(@ApiParam(name = "id", value = "学号", required = true) @PathVariable("id") String id) {
        if ("1".equals(id)) {
            return MyResponse.ok(StudentDTO.builder().id(1).name("张三").sex("1").age(18).build());
        }else {
            return MyResponse.fail("查无此学号！！！");
        }
    }
}
