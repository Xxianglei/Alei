package com.kang.learning.springboot.common.consts;

/**
 * @author yingKang
 * @date 2020-07-10 21:10
 */
public final class CodeConst {
    public static final String CODE_SUCCESS = "0";
    public static final String CODE_INTERNAL_SERVER_ERROR = "500";
    public static final String CODE_UNAUTHENTICATED = "401";
    public static final String CODE_UNAUTHORIZED = "403";
}
