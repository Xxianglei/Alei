package com.kang.learning.springboot.common.config;

import io.swagger.annotations.Api;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;


/**
 * @author yingKang
 * @Company Java编程之道
 */
@Configuration
public class SwaggerAutoConfiguration {

    private static final String TITLE = "Restful-API";
    private static final String DESC = "Restful-API的描述";
    private static final String VERSION = "1.0";

    @Bean
    public Docket createRestApi()
    {
        //Swagger实例Bean是Docket，所以必须通过配置Docket实例来配置Swagger。
        return new Docket(DocumentationType.SWAGGER_2)
                //配置Swagger标题信息
                .apiInfo(apiInfo())
                //是否启用Swagger，关闭则无法访问Swagger页面，默认为true
                .enable(true)
                .select()
                //添加过滤条件
                .apis(RequestHandlerSelectors.withClassAnnotation(Api.class))
                //通过请求路径过滤Api，这里设置为所有
                .paths(PathSelectors.any())
                .build();
    }

    private ApiInfo apiInfo()
    {
        return new ApiInfoBuilder()
                // 标题
                .title(TITLE)
                // 描述
                .description(DESC)
                // 版本
                .version(VERSION)
                .build();
    }

}
