package com.kang.learning.springboot.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author yingKang
 * @date 2020-07-11 23:44
 * @Company Java编程之道
 */
@RestController
@RequestMapping("/first")
public class FirstController {

    @GetMapping("/hello")
    public String helloWorld() {
        return "Hello World!";
    }

}
