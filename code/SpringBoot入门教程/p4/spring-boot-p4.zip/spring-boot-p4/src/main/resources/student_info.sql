/*
 Navicat Premium Data Transfer

 Source Server         : 127.0.0.1
 Source Server Type    : MySQL
 Source Server Version : 80020
 Source Host           : localhost:3306
 Source Schema         : service

 Target Server Type    : MySQL
 Target Server Version : 80020
 File Encoding         : 65001

*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for student_info
-- ----------------------------
DROP TABLE IF EXISTS `student_info`;
CREATE TABLE `student_info`  (
  `id` int(0) NOT NULL COMMENT '学号',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '姓名',
  `sex` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '性别',
  `age` int(0) NULL DEFAULT NULL COMMENT '年龄',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of student_info
-- ----------------------------
INSERT INTO `student_info` VALUES (1, '张三1号', '男', 18);
INSERT INTO `student_info` VALUES (2, '张三2号', '男', 16);
INSERT INTO `student_info` VALUES (3, '张三3号', '男', 17);
INSERT INTO `student_info` VALUES (4, '张三4号', '男', 18);
INSERT INTO `student_info` VALUES (5, '酸菜翠花', '女', 18);
INSERT INTO `student_info` VALUES (6, '豆腐翠花', '女', 17);
INSERT INTO `student_info` VALUES (7, '奶茶翠花', '女', 16);

SET FOREIGN_KEY_CHECKS = 1;
