package com.kang.learning.springboot.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.kang.learning.springboot.common.consts.MyParamConst;
import com.kang.learning.springboot.dao.StudentDAO;
import com.kang.learning.springboot.mapper.StudentMapper;
import com.kang.learning.springboot.model.dto.MyResponse;
import com.kang.learning.springboot.model.dto.StudentDTO;
import com.kang.learning.springboot.model.entity.Student;
import com.kang.learning.springboot.model.vo.QueryConditionVO;
import com.kang.learning.springboot.service.StudentService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;


/**
 * @author yingKang
 * @Company Java编程之道
 */
@Api(tags = "第一个Collector")
@RestController
@RequestMapping("/first")
public class FirstController {

    @Value(value = "${my-param.hello}")
    private String hello;

    @Value(value = "${my-param.world}")
    private String world;

    @Autowired
    private MyParamConst myParamConst;
    @Autowired
    private StudentService studentService;

    @ApiOperation(value = "直接打印Hello World")
    @GetMapping("/hello")
    public String helloWorld() {
        return "Hello World!";
    }

    @ApiOperation(value = "@Value读取打印Hello World")
    @GetMapping("/hello2")
    public String helloWorld2() {
        return "@Value: " + hello + " " + world;
    }

    @ApiOperation(value = "@ConfigurationProperties读取打印Hello World")
    @GetMapping("/hello3")
    public String helloWorld3() {
        return  "@ConfigurationProperties： " + myParamConst.getHello() + " " + myParamConst.getWorld();
    }

    @ApiOperation(value = "新建学生信息")
    @PostMapping("/student")
    public MyResponse<StudentDTO> createStudent(@ApiParam("学生信息") @RequestBody StudentDTO studentDTO) {
        return MyResponse.ok(studentDTO);
    }

    @ApiOperation(value = "查询学生信息")
    @GetMapping("/student/{id}")
    public MyResponse<StudentDTO> getStudent(@ApiParam(name = "id", value = "学号", required = true) @PathVariable("id") String id) {
        if ("1".equals(id)) {
            return MyResponse.ok(StudentDTO.builder().id(1).name("张三").sex("1").age(18).build());
        }else {
            return MyResponse.fail("查无此学号！！！");
        }
    }

    /*--------------------- P4 ------------------------------
        这里偷了个懒，直接将实体类返回给了前端。
        这是不规范的做法，小伙伴们千万不要模仿哦！！！

        按理应将实体类转换成与前端交互的DTO或者VO对象后在返回给前端。
        这样我们可以控制哪些信息暴露给用户，而不是一股脑全丢出去。
     */

    @ApiOperation(value = "按学号查询学生信息")
    @GetMapping("/student-info/{id}")
    public MyResponse<Student> getStudentInfo(@ApiParam(name = "id", value = "学号", required = true) @PathVariable("id") String id) {
        try {
            Student student = studentService.queryById(id);
            return MyResponse.ok(student);
        }catch (Exception e) {
            return MyResponse.fail("查询学生信息失败：" + e.getMessage());
        }
    }

    @ApiOperation(value = "分页条件查询学生信息")
    @PostMapping("/students/{index}/{size}")
    public MyResponse<Page<Student>> pageStudents(@ApiParam(name = "index", value = "页码", required = true) @PathVariable("index") Integer index,
                                                  @ApiParam(name = "size", value = "页大小", required = true) @PathVariable("size") Integer size,
                                                  @ApiParam(value = "查询条件") @RequestBody QueryConditionVO condition) {
        try {
            Page<Student> student = studentService.pageStudents(index, size, condition);
            return MyResponse.ok(student);
        }catch (Exception e) {
            return MyResponse.fail("分页条件查询学生信息失败：" + e.getMessage());
        }
    }
}
