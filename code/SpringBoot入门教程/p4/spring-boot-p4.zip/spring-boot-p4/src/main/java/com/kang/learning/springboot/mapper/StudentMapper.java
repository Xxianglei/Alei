package com.kang.learning.springboot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.kang.learning.springboot.model.entity.Student;
import com.kang.learning.springboot.model.vo.QueryConditionVO;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;


/**
 * @author yingKang
 * @Company : Java编程之道
 */
@Repository
public interface StudentMapper extends BaseMapper<Student> {

    /**
     * 分页条件查询
     * @param page
     * @param condition
     * @return
     */
    public IPage<Student> pageStudentByCondition(@Param("page")Page page,
                                                @Param("condition")QueryConditionVO condition);
}

