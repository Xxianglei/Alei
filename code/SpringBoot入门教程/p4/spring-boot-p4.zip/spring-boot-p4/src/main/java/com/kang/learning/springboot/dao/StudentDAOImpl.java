package com.kang.learning.springboot.dao;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.kang.learning.springboot.mapper.StudentMapper;
import com.kang.learning.springboot.model.entity.Student;
import org.springframework.stereotype.Service;

/**
 * @author yingKang
 * @Company Java编程之道
 */
@Service
public class StudentDAOImpl extends ServiceImpl<StudentMapper, Student> implements StudentDAO {
}
