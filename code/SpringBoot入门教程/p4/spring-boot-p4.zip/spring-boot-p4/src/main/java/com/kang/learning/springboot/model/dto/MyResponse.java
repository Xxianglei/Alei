package com.kang.learning.springboot.model.dto;


import com.kang.learning.springboot.common.consts.CodeConst;

import java.io.Serializable;

/**
 * @author yingKang
 * @Company Java编程之道
 */
public class MyResponse<T> implements Serializable {
    /**
     * 状态码 : 0-成功；401-无认证信息；403-访问受限；404-请求地址不存在；500-服务处理请求异常
     */
    private String code;

    /**
     * 错误消息
     */
    private String message;

    /**
     * 响应数据内容
     */
    private T data;


    protected MyResponse() {
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    public T getData() {
        return data;
    }

    public MyResponse<T> code(String code) {
        this.code = code;
        return this;
    }

    public MyResponse<T> data(T data) {
        this.data = data;
        return this;
    }

    public MyResponse<T> message(String message) {
        this.message = message;
        return this;
    }

    public static <T> MyResponse<T> ok() { return new MyResponse<T>().code(CodeConst.CODE_SUCCESS); }

    public static <T> MyResponse<T> ok(T data) { return new MyResponse<T>().code(CodeConst.CODE_SUCCESS).data(data); }

    public static <T> MyResponse<T> fail() { return new MyResponse<T>().code(CodeConst.CODE_INTERNAL_SERVER_ERROR); }

    public static <T> MyResponse<T> fail(String message) {
        return new MyResponse<T>().code(CodeConst.CODE_INTERNAL_SERVER_ERROR).message(message);
    }

    public static <T> MyResponse<T> of() { return new MyResponse<>(); }

    public static <T> MyResponse<T> of(String code) { return new MyResponse<T>().code(code); }

    public static <T> MyResponse<T> of(String code, String message) { return new MyResponse<T>().code(code).message(message); }

    public boolean isOk()
    {
        return CodeConst.CODE_SUCCESS.equals(code);
    }

    @Override
    public String toString() {
        return getClass().getName() + "{"
                + "code='" + code + "'"
                + ", messages=" + message
                + ", data=" + data
                + "}";
    }
}
