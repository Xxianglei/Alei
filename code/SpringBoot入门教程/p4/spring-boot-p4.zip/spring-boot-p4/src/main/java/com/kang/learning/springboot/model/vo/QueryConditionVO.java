package com.kang.learning.springboot.model.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 查询条件
 *
 * @author yingKang
 * @Company Java编程之道
 */
@ApiModel("查询条件")
@Data
public class QueryConditionVO {

    @ApiModelProperty("学生姓名")
    private String name;

    @ApiModelProperty("学生性别")
    private String sex;

}
