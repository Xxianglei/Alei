package com.kang.learning.springboot.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.kang.learning.springboot.model.entity.Student;
import com.kang.learning.springboot.model.vo.QueryConditionVO;

/**
 * 学生信息Service层
 * @author yingKang
 * @date Java编程之道
 */
public interface StudentService {

    /**
     * 通过学号查询学生信息
     * @param id
     * @return
     */
    Student queryById(String id);

    /**
     * 分页条件查询学生信息
     *
     * @param index
     * @param size
     * @param condition
     * @return
     */
    Page<Student> pageStudents(Integer index, Integer size, QueryConditionVO condition);
}
