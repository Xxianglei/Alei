package com.kang.learning.springboot.model.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

/**
 * @author yingKang
 * @Company Java编程之道
 */
@Data
@AllArgsConstructor
@Builder
@ApiModel(value = "学生类")
public class StudentDTO {

    @ApiModelProperty("学号")
    private Integer id;

    @ApiModelProperty("姓名")
    private String name;

    @ApiModelProperty(value = "学号", example = "1:男 | 0:女")
    private String sex;

    @ApiModelProperty("年龄")
    private Integer age;

}
