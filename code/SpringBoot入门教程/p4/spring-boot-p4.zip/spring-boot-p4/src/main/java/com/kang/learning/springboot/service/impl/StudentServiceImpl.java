package com.kang.learning.springboot.service.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.kang.learning.springboot.dao.StudentDAO;
import com.kang.learning.springboot.model.entity.Student;
import com.kang.learning.springboot.model.vo.QueryConditionVO;
import com.kang.learning.springboot.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author yingKang
 * @date Java编程之道
 */
@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentDAO studentDAO;

    @Override
    public Student queryById(String id) {
        if (id == null){return null;}
        return studentDAO.getById(id);
    }

    @Override
    public Page<Student> pageStudents(Integer index, Integer size, QueryConditionVO condition) {
        //构造分页对象
        Page<Student> page = new Page<>(index, size);

        /*
            分页条件查询接口，无SQL实现查询的精髓就是 Mybatis-Plus的条件构造器
            具体用法可以参考官网：https://mybatis.plus/guide/wrapper.html，学习起来也很快
            示例中的条件构造等同于SQL：
            当condition.getName()与condition.getName()均不为空时：
                SELECT * FROM student_info WHERE name = condition.getName() AND sex = condition.getName();
            若condition.getName()与condition.getName()均为空时：
                SELECT * FROM student_info；
         */
        return studentDAO.page(page, Wrappers.<Student>lambdaQuery()
                .eq(!isNull(condition.getName()), Student::getName, condition.getName())
                .eq(!isNull(condition.getSex()), Student::getSex, condition.getSex()));
    }

    private boolean isNull(String var) {
        return var == null || "".equals(var) || "".equals(var.trim());
    }
}
