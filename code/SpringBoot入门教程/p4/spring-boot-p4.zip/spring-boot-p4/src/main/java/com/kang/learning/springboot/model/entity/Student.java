package com.kang.learning.springboot.model.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

//lombok注解可简化get和set方法
@Data
//同数据库表名一致
@TableName("student_info")
public class Student implements Serializable {
    private static final long serialVersionUID = 8841121918405694010L;

    /*参数命名需同数据库字段名称保持一致，但数据库下划线可转为驼峰规则命名
        eg: 数据库字段：classify_id  实体类中对应字段：classifyId
     */
    //表名主键
    @TableId
    private String id;

    @TableField
    private String name;

    @TableField
    private String sex;

    @TableField
    private Integer age;

    //标识其不为数据库字段
    @TableField(exist = false)
    private String address;

}