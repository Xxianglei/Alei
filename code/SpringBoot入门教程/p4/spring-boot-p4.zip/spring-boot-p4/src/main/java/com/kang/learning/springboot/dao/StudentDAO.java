package com.kang.learning.springboot.dao;

import com.baomidou.mybatisplus.extension.service.IService;
import com.kang.learning.springboot.model.entity.Student;

/**
 * @author yingKang
 * @Company  Java编程之道
 */
public interface StudentDAO extends IService<Student> {
}
